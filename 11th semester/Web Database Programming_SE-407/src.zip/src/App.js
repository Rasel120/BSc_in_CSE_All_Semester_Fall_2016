import React from 'react';
import ReactDOM from 'react-dom';
import Header from './component/Header';
import Content from './component/Content';
import Footer from './component/Footer';
import './style.css';
function App() 
{
   return( 
   <div>
       <Header />
       <Content />
       <Footer />
    </div>
       )
}
export default App ;
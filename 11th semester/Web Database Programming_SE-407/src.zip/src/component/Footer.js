import React from 'react';
import ReactDOM from 'react-dom';
function Footer(){
    
    return(
        
        <footer> This is header </footer>
    
    )
}
export default Footer ;
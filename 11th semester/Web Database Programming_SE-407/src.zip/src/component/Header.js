import React from 'react';
import ReactDOM from 'react-dom';
function Header(){
    const Style={color:"red",
                 textAlign:"center", 
                 backgroundColor:"green"
                }
    
    
    return(
        
        <h1 style={Style}> This is header {a+b} </h1>
    
    )
}
export default Header ;
import React from 'react';
import ReactDOM from 'react-dom';
function Content(){
    
    return(
        
        <div className="cont"><h1> This is Content </h1></div>
    
    )
}
export default Content ;
import React from 'react';
import ReactDOM from 'react-dom';
function List()
{
    
   return(
       <div>
       <h1> List item goes from here Using React </h1>
   <ul> 
    <li>1 </li>
    <li>2 </li> 
    <li> 3</li>
    </ul>
       <h1> Batch  43</h1>
       <h1> Batch  43</h1>
       <footer> This is footer</footer>
       </div>
       
   
   )
    
    
}
export default List ;
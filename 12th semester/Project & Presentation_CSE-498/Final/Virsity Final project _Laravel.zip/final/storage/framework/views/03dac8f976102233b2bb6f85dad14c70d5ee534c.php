<?php $__env->startSection('content'); ?>
  <div class='container mt-2'>
    <div class="row">
      <div class="col-md-4">
        <div class="list-group">
          <a href="" class="list-group-item">
            <img src="<?php echo e(App\Helpers\ImageHelper::getUserImage(Auth::user()->id)); ?>" class="img rounded-circle" style="width:100px">
          </a>
          <a href="<?php echo e(route('user.dashboard')); ?>" class="list-group-item <?php echo e(Route::is('user.dashboard') ? 'active' : ''); ?>">Dashboard</a>
          <a href="<?php echo e(route('user.profile')); ?>" class="list-group-item <?php echo e(Route::is('user.profile') ? 'active' : ''); ?>">Update Profile</a>

        </div>
      </div>
      <div class="col-md-8">
        <div class="card card-body">
          <?php echo $__env->yieldContent('sub-content'); ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
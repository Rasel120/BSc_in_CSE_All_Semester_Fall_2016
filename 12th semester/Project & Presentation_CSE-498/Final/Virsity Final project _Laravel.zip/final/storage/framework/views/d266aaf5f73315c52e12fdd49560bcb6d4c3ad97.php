<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">

    <div class="card">
      <div class="card-header">
        View Order #LE<?php echo e($order->id); ?>

      </div>
      <div class="card-body">
        <?php echo $__env->make('backend.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <h3>Order Inromations</h3>
        <div class="row">
          <div class="col-md-6 border-right">
            <p><strong>Orderer Name : </strong><?php echo e($order->name); ?></p>
            <p><strong>Orderer Phone : </strong><?php echo e($order->phone_no); ?></p>
            <p><strong>Orderer Email : </strong><?php echo e($order->email); ?></p>
          </div>
          <div class="col-md-6">
            <p><strong>Order Payment Method: </strong> <?php echo e($order->payment->name); ?></p>
            <p><strong>Order Payment Transaction: </strong> <?php echo e($order->transaction_id); ?></p>
          </div>
        </div>
        <hr>
        <h3>Ordered Items: </h3>

        <?php if($order->carts->count() > 0): ?>
        <table class="table table-bordered table-stripe">
          <thead>
            <tr>
              <th>No</th>
              <th>Product Title</th>
              <th>Product Image</th>
              <th>Product Quantity</th>
              <th>Price</th>
              <th>Total Price</th>
              <th>
                Delete
              </th>
            </tr>
          </thead>
          <tbody>
            <?php
            $total_price = 0;
            ?>
            <?php $__currentLoopData = $order->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($loop->index + 1); ?>

              </td>
              <td>
                <a href="<?php echo e(route('products.show', $cart->product->slug)); ?>"><?php echo e($cart->product->title); ?></a>
              </td>
              <td>
                <?php if($cart->product->images->count() > 0): ?>
                <img src="<?php echo e(asset('images/products/'. $cart->product->images->first()->image)); ?>" width="60px">
                <?php endif; ?>
              </td>
              <td>
                <form class="form-inline" action="<?php echo e(route('carts.update', $cart->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="number" name="product_quantity" class="form-control" value="<?php echo e($cart->product_quantity); ?>"/>
                  <button type="submit" class="btn btn-success ml-1">Update</button>
                </form>
              </td>
              <td>
                <?php echo e($cart->product->price); ?> Taka
              </td>
              <td>
                <?php
                $total_price += $cart->product->price * $cart->product_quantity;
                ?>

                <?php echo e($cart->product->price * $cart->product_quantity); ?> Taka
              </td>
              <td>
                <form class="form-inline" action="<?php echo e(route('carts.delete', $cart->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="cart_id" />
                  <button type="submit" class="btn btn-danger">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td colspan="4"></td>
              <td>
                Total Amount
              </td>
              <td colspan="2">
                <strong>  <?php echo e($total_price); ?> Taka</strong>
              </td>
            </tr>
          </tbody>
        </table>
        <?php endif; ?>

        <hr>

        <form action="<?php echo e(route('admin.order.completed', $order->id)); ?>" class="form-inline" style="display: inline-block!important;" method="post">
          <?php echo csrf_field(); ?>
          <?php if($order->is_completed): ?>
          <input type="submit" value="Cancel Order" class="btn btn-danger">
          <?php else: ?>
          <input type="submit" value="Complete Order" class="btn btn-success">
          <?php endif; ?>
        </form>


        <form action="<?php echo e(route('admin.order.paid', $order->id)); ?>" class="form-inline" style="display: inline-block!important;" method="post">
          <?php echo csrf_field(); ?>
          <?php if($order->is_paid): ?>
          <input type="submit" value="Cancel Payment " class="btn btn-danger">
          <?php else: ?>
          <input type="submit" value="Paid Order" class="btn btn-success">
          <?php endif; ?>
        </form>

      </div>
    </div>

  </div>
</div>
<!-- main-panel ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2021 at 07:37 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Super Admin' COMMENT 'Admin|Super Admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `phone_no`, `avatar`, `remember_token`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Rasel', 'raselcse120@gmail.com', '$2y$10$QHRCe5wQO.Ypsnfbbcqw9u7q8yQXQGnXoqjHmAY0/bEPufgl6Ga.6', '01821112191', NULL, 'V3Kpm0wxl8ZLaan2et7JrdnufN055DEplgyT0OFdzvrd1HPg2gyIPS9ATEdF', 'Super Admin', '2021-03-11 23:59:08', '2021-03-17 08:27:28'),
(2, 'piyas', 'piyas.bogra@gmail.com', '$2y$10$DCvXCGTtbaKDQdeTFprcOe0z0Bk53xK14Uf37NNnYJ0wjV4Pw942m', '01717291214', NULL, NULL, 'Super Admin', '2021-03-12 20:59:32', '2021-03-12 20:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Samsung', NULL, '1615553884.jpg', '2021-03-12 06:58:05', '2021-03-12 06:58:05'),
(3, 'Iphone', NULL, '1615553965.jpg', '2021-03-12 06:59:25', '2021-03-12 06:59:25'),
(4, 'Sony', NULL, '1615554557.jpg', '2021-03-12 07:09:17', '2021-03-12 07:09:17'),
(5, 'Realme', 'Realme Mobile Phones', NULL, '2021-04-07 16:12:19', '2021-04-07 16:12:19'),
(6, 'Dell', NULL, '1617813345.jpg', '2021-04-07 16:35:46', '2021-04-07 16:35:46'),
(7, 'HP', NULL, NULL, '2021-04-07 16:37:47', '2021-04-07 16:50:30'),
(8, 'Walton', NULL, NULL, '2021-04-07 16:39:28', '2021-04-07 16:39:28'),
(9, 'Canon', NULL, NULL, '2021-04-07 17:02:24', '2021-04-07 17:02:24');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `order_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `user_id`, `order_id`, `ip_address`, `product_quantity`, `created_at`, `updated_at`) VALUES
(26, 5, 1, 8, '::1', 3, '2021-03-20 11:19:06', '2021-03-23 09:54:39'),
(27, 3, NULL, NULL, '::1', 2, '2021-03-20 11:23:31', '2021-03-20 11:34:38'),
(28, 2, 1, 8, '::1', 3, '2021-03-20 11:24:10', '2021-03-23 09:54:39'),
(29, 4, NULL, NULL, '::1', 1, '2021-03-20 11:34:52', '2021-03-20 11:34:52'),
(31, 1, NULL, NULL, '::1', 1, '2021-03-20 11:36:30', '2021-03-20 11:36:30'),
(35, 1, 1, 12, '127.0.0.1', 1, '2021-04-07 14:46:57', '2021-04-07 14:49:08');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`, `parent_id`, `created_at`, `updated_at`) VALUES
(2, 'Mobile', 'Mobile', '1617813210.jpg', NULL, '2021-03-12 07:01:38', '2021-04-07 16:33:30'),
(3, 'Samsung', NULL, '1615554130.jpg', 2, '2021-03-12 07:02:10', '2021-03-12 07:02:23'),
(4, 'Iphone', NULL, '1615554160.jpg', 2, '2021-03-12 07:02:40', '2021-03-12 07:02:40'),
(5, 'Tv', NULL, '1615554184.jpg', NULL, '2021-03-12 07:03:04', '2021-03-12 07:03:04'),
(6, 'Sony', 'Sony', '1615554210.jpg', 5, '2021-03-12 07:03:30', '2021-03-12 07:03:30'),
(7, 'Smart Tv', NULL, '1615554235.jpg', 5, '2021-03-12 07:03:56', '2021-03-12 07:03:56'),
(8, 'Realme', 'Realme Mobile Phones', '1617812047.jpg', 2, '2021-04-07 16:14:08', '2021-04-07 16:14:08'),
(9, 'Laptops', 'Laptops', '1617813143.jpg', NULL, '2021-04-07 16:32:23', '2021-04-07 16:32:23'),
(10, 'Dell', NULL, '1617813386.jpg', 9, '2021-04-07 16:36:26', '2021-04-07 16:36:26'),
(11, 'Walton', NULL, '1617813691.jpg', 9, '2021-04-07 16:41:31', '2021-04-07 16:41:31'),
(12, 'HP', NULL, '1617813782.jpg', 9, '2021-04-07 16:43:02', '2021-04-07 16:43:02'),
(13, 'Camera', NULL, '1617814885.jpg', NULL, '2021-04-07 17:01:26', '2021-04-07 17:01:26'),
(14, 'Canon', NULL, '1617815057.jpg', 13, '2021-04-07 17:04:17', '2021-04-07 17:04:17'),
(15, 'Tablet', NULL, '1617815354.jpg', NULL, '2021-04-07 17:09:14', '2021-04-07 17:09:14'),
(16, 'Tablet', NULL, '1617815659.jpg', 15, '2021-04-07 17:14:20', '2021-04-07 17:14:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2014_10_12_000000_create_users_table', 3),
(3, '2021_03_12_053833_create_payments_table', 10),
(5, '2021_03_12_054306_create_carts_table', 12),
(6, '2021_03_12_054430_create_orders_table', 13),
(7, '2021_03_12_054553_create_product_images_table', 14),
(8, '2021_03_12_054659_create_admins_table', 15),
(9, '2021_03_12_054803_create_brands_table', 16),
(10, '2021_03_12_054901_create_categories_table', 17),
(11, '2021_03_12_055035_create_products_table', 18);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `payment_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',
  `is_seen_by_admin` tinyint(1) NOT NULL DEFAULT '0',
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `payment_id`, `ip_address`, `name`, `phone_no`, `email`, `message`, `is_paid`, `is_completed`, `is_seen_by_admin`, `transaction_id`, `created_at`, `updated_at`) VALUES
(1, NULL, 3, '127.0.0.1', 'Sony', '01821112191', 'raselcse120@gmail.com', NULL, 1, 1, 1, '3452345', '2021-03-12 07:57:18', '2021-03-17 02:56:26'),
(2, 13, 3, '127.0.0.1', 'viteh98482@naymio.com viteh98482@naymio.com', '01821767456', 'viteh98482@naymio.com', NULL, 1, 1, 1, '3452345', '2021-03-17 02:46:28', '2021-03-17 02:57:16'),
(3, 1, 3, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 1, 1, 1, '4534', '2021-03-17 07:25:08', '2021-03-17 07:25:31'),
(4, 1, 2, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 0, 0, 1, '3452345', '2021-03-17 07:26:25', '2021-03-17 07:26:38'),
(5, 1, 1, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 1, 0, 1, NULL, '2021-03-17 07:28:06', '2021-03-17 07:28:18'),
(6, NULL, 2, '127.0.0.1', 'Iphone', '01845643254', 'raselcse120@gmail.com', NULL, 0, 0, 0, '4534', '2021-03-17 07:28:58', '2021-03-17 07:28:58'),
(7, 1, 2, '::1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 0, 0, 0, '5353', '2021-03-20 10:42:33', '2021-03-20 10:42:33'),
(8, 1, 1, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 1, 0, 1, NULL, '2021-03-23 09:54:39', '2021-03-23 09:55:42'),
(9, 1, 1, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 0, 0, 0, NULL, '2021-03-23 16:30:02', '2021-03-23 16:30:02'),
(10, 1, 1, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 0, 0, 1, NULL, '2021-04-07 14:46:11', '2021-04-07 14:49:33'),
(11, 1, 2, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 1, 1, 1, '4563', '2021-04-07 14:47:22', '2021-04-07 14:48:05'),
(12, 1, 1, '127.0.0.1', 'Rasel Hossain', '01821112191', 'raselcse120@gmail.com', NULL, 0, 0, 0, NULL, '2021-04-07 14:49:08', '2021-04-07 14:49:08');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('kotel13482@990ys.com', '$2y$10$FfxC.n8rZxcYagV6BC.6Ze4.XeF.pz026BjQVySx0MBJKoBdShEle', '2021-03-12 09:31:43'),
('xiviwim881@leonvero.com', '$2y$10$QDcBkevK5o6HMr0Cg24CBe.nG1GKb4OMa317OZvhUQ.DN8kZCe.ja', '2021-03-17 00:37:47'),
('sisomok659@heroulo.com', '$2y$10$PxsJec.tbi6kdJyqxlOXDurXTVa8f9z6bwQMq/u7p.div43LufYRq', '2021-03-17 04:52:48');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT '1',
  `short_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Payment No',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'agent|personal',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `name`, `image`, `priority`, `short_name`, `no`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Cash', 'cash_in.jpg', 1, 'cash_in', NULL, NULL, '2021-02-28 18:00:00', '2021-03-01 18:00:00'),
(2, 'Bkash', 'bkash.jpg', 1, 'bkash', NULL, NULL, '2021-03-01 18:00:00', '2021-03-01 18:00:00'),
(3, 'Rocket', 'rocket.jpg', 1, 'rocket', NULL, NULL, '2021-03-01 18:00:00', '2021-03-01 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `brand_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `price` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `offer_price` int(11) DEFAULT NULL,
  `admin_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `title`, `description`, `slug`, `quantity`, `price`, `status`, `offer_price`, `admin_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'Samsung Mobile', 'Samsung Mobile', 'samsung-mobile', 5, 10000, 0, NULL, 1, '2021-03-12 07:05:05', '2021-03-12 07:05:05'),
(2, 3, 1, 'Samsung Mobile M20', 'Samsung Mobile', 'samsung-mobile-m20', 10, 12000, 0, NULL, 1, '2021-03-12 07:05:46', '2021-03-17 03:08:43'),
(3, 7, 4, 'Smart Tv', 'Smart Tv', 'smart-tv', 8, 15000, 0, NULL, 1, '2021-03-12 07:07:13', '2021-03-17 03:08:17'),
(4, 3, 1, 'Samsung M10', 'Samsung M10', 'samsung-m10', 4, 12000, 0, NULL, 1, '2021-03-17 03:05:34', '2021-03-17 03:07:53'),
(5, 4, 3, 'Iphone', 'Iphone', 'iphone', 5, 50000, 0, NULL, 1, '2021-03-17 03:09:41', '2021-03-17 03:09:41'),
(6, 8, 5, 'realme C17 - 6GB/ 128GB Smartphone', 'Product details of realme C17 - 6GB/ 128GB Smartphone\r\nDISPLAY Type: IPS LCD capacitive touchscreen WITH 90Hz screen refresh rate\r\nSize: 6.5”\r\nResolution: 720 x 1600 pixels\r\nOS:Android 10 realme UI\r\nChipset: Qualcomm SM4250 Snapdragon 460 (11 nm)\r\nCPU:Octa-core: Octa-core (4x1.8 GHz Kryo 240 & 4x1.6 GHz Kryo 240)\r\nGPU: Adreno 610\r\nMEMORY:RAM: 6GB, ROM: 128GB\r\nCard Slot: microSDXC (dedicated slot)\r\nRear Camera: Quad 13+8+2+2 MP\r\nFront Camera: Single 8 MP\r\nUSB:2.0, Type-C 1.0 reversible connector, USB On-The-Go\r\nSensors: Fingerprint (side-mounted), accelerometer, gyro, proximity, compass\r\nNon-removable Li-Po 5000mAh battery\r\nCharging: Fast charging 18W', 'realme-c17-6gb-128gb-smartphone', 54, 15490, 0, NULL, 1, '2021-04-07 16:17:49', '2021-04-07 16:19:42'),
(7, 8, 5, 'Realme 7 Pro - 8GB RAM / 128GB ROM', 'Product details of Realme 7 Pro - 8GB RAM / 128GB ROM\r\nNO RETURN applicable if the seal is broken\r\nBODY Dimensions: 160.9 x 74.3 x 8.7 mm (6.33 x 2.93 x 0.34 in)\r\nWeight: 182 g (6.42 oz)\r\nSIM:Dual SIM (Nano-SIM, dual stand-by)\r\nWater-repellent coating\r\nDISPLAY: Type Super AMOLED\r\nSize: 6.4 inches, 98.9 cm2 (~82.7% screen-to-body ratio)\r\nResolution: 1080 x 2400 pixels, 20:9 ratio (~411 ppi density)\r\nProtection:Corning Gorilla Glass 3+\r\nOS: Android 10, Realme UI\r\nChipset :Qualcomm SM7125 Snapdragon 720G (8 nm)\r\nCPU: Octa-core (2x2.3 GHz Kryo 465 Gold & 6x1.8 GHz Kryo 465 Silver)\r\nGPU:Adreno 618\r\nMEMORY:Card slot microSDXC (dedicated slot)\r\nInternal:8GB RAM / 128GB ROM\r\nMAIN CAMERA (Quad): 64 MP,8 MP, 2 MP,2 MP, f/2.4, (depth)\r\nFeatures:LED flash, HDR, panorama\r\nVideo:4K@30fps, 1080p@30/60/120fps, gyro-EIS\r\nSELFIE CAMERA (Single):32 MP, f/2.5, 24mm (wide), 1/2.8\", 0.8µm\r\nFeatures:HDR, panorama\r\nVideo:1080p@30/120fps, gyro-EIS\r\nSOUND Loudspeaker:Yes, with stereo speakers\r\n3.5mm jack: Yes\r\n24-bit/192kHz audio\r\nCOMMS: WLAN Wi-Fi 802.11 a/b/g/n/ac, dual-band, Wi-Fi Direct, hotspot\r\nBluetooth:5.1, A2DP, LE\r\nGPS :Yes, with A-GPS, GLONASS, BDS, NavIC\r\nRadio: No\r\nUSB Type-C 2.0, USB On-The-Go\r\nFEATURES: Sensors Fingerprint (under display, optical), accelerometer, gyro, proximity, compass\r\nBATTERY Type:Li-Po 4500 mAh, non-removable\r\nCharging:Fast charging 65W, 50% in 12 min, 100% in 34 min', 'realme-7-pro-8gb-ram-128gb-rom', 23, 27990, 0, NULL, 1, '2021-04-07 16:20:49', '2021-04-07 16:20:49'),
(8, 7, 4, 'SMART/WIFI HD LED TV DN600D', 'Product details of 40\'\' LUCAS ( RAM 1 GB - ROM 8 GB ) SMART/WIFI HD LED TV DN600D\r\nBrand: LUCAS=( RAM 1 GB - ROM 8 GB )\r\nModel: DN600D\r\nDisplay Device: smart /wifi /android HD LED Tv\r\nScreen Size:40”\r\nResolution1080 x 1366*768 ( HD)\r\nAndroid Operating System( RAM-1 GB-ROM 8 GB )\r\nAndroid Operating version Built-In\r\nDVD/CD Port\r\nDies Port\r\nWi-Fi- 802.11\r\nHDMI\r\nUSB\r\nLan Port\r\nAV Output\r\nAudio Out Port\r\nMouse Supported\r\nSpeaker 2 pcs Multimedia Build in\r\nVideo Format FULL HD Supported\r\nFree Thunder Strom Protector\r\nFree Wall Mount Bracket', 'smartwifi-hd-led-tv-dn600d', 54, 19500, 0, NULL, 1, '2021-04-07 16:23:56', '2021-04-07 16:23:56'),
(9, 6, 4, 'Sony 32\'\' KDL-32W600D', 'Product details of Sony 32\'\' KDL-32W600D / 32W602D Internet /SMART TV SLIM ( MALAYSIA )\r\nDisplay: 32\"SONY\r\nLED Panel\r\nX-Reality PRO\r\n720p (1366 x 768)\r\nMotionflow XR 240\r\nScreen Mirroring Technology\r\nBuilt-In Wi-Fi', 'sony-32-kdl-32w600d', 43, 26500, 0, NULL, 1, '2021-04-07 16:26:17', '2021-04-07 16:26:17'),
(10, 6, 4, '32\'\' SONY PLUS HD LED TV', 'Product details of 32\'\' SONY PLUS HD LED TV (4K SUPPORTED)\r\nBrand name:= sony plus\r\nALTRA SLIM HD LED TV + Monitor\r\nResolution1080P 1366 x 768\r\nHDMI\r\nUSB\r\nLan Port\r\nAV Output\r\nAudio Out Port\r\nSpeaker 2 pcs Multimedia Build in\r\nVideo Format FULL HD Supported\r\nWall Mount allows you to hang on the wall\r\nCan be used as CC Camera Monitor\r\nPower: Low voltage and 90% saving your power', '32-sony-plus-hd-led-tv', 54, 14500, 0, NULL, 1, '2021-04-07 16:30:36', '2021-04-07 16:30:36'),
(11, 10, 6, 'Dell Inspiron 15 3583 Intel Pentium Gold 5405U', 'Product details of Dell Inspiron 15 3583 Intel Pentium Gold 5405U (2.30GHz, 4GB DDR4, 1TB HDD, No-ODD) 15.6 Inch HD (1366x768) Display, Win 10, McAfee Antivirus, Black Notebook\r\nNotebook Series - Inspiron\r\nProcessor Brand - Intel\r\nProcessor Type - Pentium Gold', 'dell-inspiron-15-3583-intel-pentium-gold-5405u', 34, 38100, 0, NULL, 1, '2021-04-07 16:37:28', '2021-04-07 16:37:28'),
(12, 11, 8, 'Walton Laptop WPRX4N50GR Intel Quad Core 14 inch - Grey (N5001)', 'Product details of Walton Laptop WPRX4N50GR Intel Quad Core 14 inch - Grey (N5001)\r\n35.56cm (14.0″) High Definition (HD) LED Panel\r\nIntel N5000 1.10GHz Processor Quad Core, Burst Frequency 2.70GHz, 4MB Cache\r\n1TB Hard Disk Drive (HDD), 5400 rpm, 7mm', 'walton-laptop-wprx4n50gr-intel-quad-core-14-inch-grey-n5001', 46, 24201, 0, NULL, 1, '2021-04-07 16:45:51', '2021-04-07 16:45:51'),
(13, 11, 8, 'Walton WTZX47U3GR Core i3 7th Gen 14 inch - Grey (ZX3701)', 'Product details of Walton WTZX47U3GR Core i3 7th Gen 14 inch - Grey (ZX3701)\r\n35.56cm (14.0\") HD Matte LED backlit display\r\nIntel® Core™ i3-7020U 2.30GHz\r\n7th Generation processor\r\n1TB HDD, 5400rpm, 7mm', 'walton-wtzx47u3gr-core-i3-7th-gen-14-inch-grey-zx3701', 545, 32607, 0, NULL, 1, '2021-04-07 16:47:11', '2021-04-07 16:47:11'),
(14, 11, 8, 'Walton WPBX48U7 Core i7 8th Gen 8GB DDR4 2400MHz RAM Laptop BX7800 14 inch', 'Product details of Walton WPBX48U7 Core i7 8th Gen 8GB DDR4 2400MHz RAM Laptop BX7800 14 inch - Black\r\n35.56cm (14.0\") HD Matte LED backlit display\r\nIntel® Core™ i7-8550U 1.80GHz\r\n8th Generation processor\r\n1TB HDD, 5400rpm, 7mm\r\n8GB DDR4 2400MHz RAM\r\n802.11ac WLAN + BT 4.2\r\nColor: Black', 'walton-wpbx48u7-core-i7-8th-gen-8gb-ddr4-2400mhz-ram-laptop-bx7800-14-inch', 54, 53482, 0, NULL, 1, '2021-04-07 16:48:51', '2021-04-07 16:48:51'),
(15, 12, 7, 'HP 15s-du3023TU 11th Gen Intel Core i3-1115G4 3 to 4.1GHz, 4GB DDR4, 1TB, 15.6FHD, Win10 Laptop', 'Product details of HP 15s-du3023TU 11th Gen Intel Core i3-1115G4 3 to 4.1GHz, 4GB DDR4, 1TB, 15.6FHD, Win10 Laptop\r\nHP Laptop 15s-du3023TU\r\nProduct Details / Specifications -\r\nProcessor - Intel Core i3-1115G4 11th Gen 3 to 4.1GHz (2 Core, 4 Thread, 6MB Cache)\r\nRAM - 4GB DDR4\r\nHDD - 1TB SATA\r\nDisplay - 15.6 Inch FHD\r\nWeb Cam - 720p\r\nBluetooth - Version 5\r\nWiFi - Realtek RTL8822CE 802.11 WiFi6\r\nBattery - 3 Cell\r\nOS - Windows 10 License\r\nOrigin - USA\r\nMake - China', 'hp-15s-du3023tu-11th-gen-intel-core-i3-1115g4-3-to-41ghz-4gb-ddr4-1tb-156fhd-win10-laptop', 44, 54500, 0, NULL, 1, '2021-04-07 16:52:42', '2021-04-07 16:52:42'),
(16, 12, 7, 'HP Envy 13-ba1040tu 11th Gen Intel Core i5 1135G7', 'Product details of HP Envy 13-ba1040tu 11th Gen Intel Core i5 1135G7 (2.40GHz-4.20GHz, 8GB DDR4, 512GB SSD, No-ODD) 13.3 Inch FHD (1920x1080) Display, Win 10, Silver Notebook 2Q4E3PA-2Y\r\nModel HP Envy 13-ba1040tu\r\nNotebook Series Envy\r\nPart No 2Q4E3PA-2Y\r\nCountry Of Origin USA\r\nMade in/ Assemble China\r\nProcessor Brand Intel\r\nProcessor Type Core i5\r\nGeneration 11th\r\nProcessor Model Core i5 1135G7\r\nProcessor Base Frequency 2.40 GHz\r\nProcessor Max Turbo Frequency 4.20 GHz\r\nProcessor Core 4\r\nProcessor Thread 8\r\nCPU Cache 8MB\r\nRAM 8GB\r\nRAM Type DDR4\r\nStorage 512GB SSD', 'hp-envy-13-ba1040tu-11th-gen-intel-core-i5-1135g7', 32, 97000, 0, NULL, 1, '2021-04-07 16:55:12', '2021-04-07 16:55:12'),
(17, 14, 9, 'Canon EOS M50 Mirrorless Digital Camera with 15-45mm Lens - Black', 'Product details of Canon EOS M50 Mirrorless Digital Camera with 15-45mm Lens - Black\r\n24.1MP APS-C CMOS Sensor\r\nDIGIC 8 Image Processor\r\n2.36m-Dot OLED Electronic Viewfinder\r\n3.0\" 1.04m-Dot Vari-Angle Touchscreen', 'canon-eos-m50-mirrorless-digital-camera-with-15-45mm-lens-black', 43, 56500, 0, NULL, 1, '2021-04-07 17:05:11', '2021-04-07 17:05:11'),
(18, 14, 9, 'anon EOS 700D + EF-S 18-55mm 3.5-5.6 IS Lens - International Version', 'Product details of Canon EOS 700D + EF-S 18-55mm 3.5-5.6 IS Lens - International Version\r\nNO RETURN Applicable If The Seal is Broken\r\nOffline EMI facilities available for products above BDT 10,000. Call 16492 for further details.\r\n18MP APS-C \'Hybrid CMOS\' sensor\r\nPhase detection AF from imaging sensor for Live View and Video\r\nContinuous autofocus in movie mode with subject tracking\r\n14-bit DIGIC 5 processor\r\nISO 100-12800 standard, 25600 expanded', 'anon-eos-700d-ef-s-18-55mm-35-56-is-lens-international-version', 33, 34150, 0, NULL, 1, '2021-04-07 17:06:45', '2021-04-07 17:06:45'),
(19, 16, 1, 'Samsung & Shonod Education Tab A8 For Class Six to Ten (Bangla Version)', 'Product details of Samsung & Shonod Education Tab A8 For Class Six to Ten (Bangla Version)\r\nIn a creative way, Video tutorial for all Classes from Class 1 to 10 (Bangla Version).\r\nStudents will can easily learn on their own way by watching tutorials on all subjects.\r\nStudents can remove the stress of private reading, as well as affordable and high-quality education while staying at home', 'samsung-shonod-education-tab-a8-for-class-six-to-ten-bangla-version', 43, 23000, 0, NULL, 1, '2021-04-07 17:11:09', '2021-04-07 17:14:59'),
(20, 16, 1, 'Samsung & Shonod Education Tab A10 For Class One to Five (Bangla Version)', 'Product details of Samsung & Shonod Education Tab A10 For Class One to Five (Bangla Version)\r\nIn a creative way, Video tutorial for all Classes from Class 1 to 10 (Bangla Version).\r\nStudents will can easily learn on their own way by watching tutorials on all subjects.\r\nStudents can remove the stress of private reading, as well as affordable and high-quality education while staying at home', 'samsung-shonod-education-tab-a10-for-class-one-to-five-bangla-version', 23, 34000, 0, NULL, 1, '2021-04-07 17:12:56', '2021-04-07 17:14:48');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, '1615554305.jpg', '2021-03-12 07:05:05', '2021-03-12 07:05:05'),
(2, 2, '1615554346.jpg', '2021-03-12 07:05:47', '2021-03-12 07:05:47'),
(3, 3, '1615554433.jpg', '2021-03-12 07:07:13', '2021-03-12 07:07:13'),
(4, 4, '1615971934.jpg', '2021-03-17 03:05:34', '2021-03-17 03:05:34'),
(5, 5, '1615972181.jpg', '2021-03-17 03:09:41', '2021-03-17 03:09:41'),
(6, 6, '1617812269.jpg', '2021-04-07 16:17:49', '2021-04-07 16:17:49'),
(7, 7, '1617812449.jpg', '2021-04-07 16:20:49', '2021-04-07 16:20:49'),
(8, 8, '1617812636.jpg', '2021-04-07 16:23:56', '2021-04-07 16:23:56'),
(9, 9, '1617812777.jpg', '2021-04-07 16:26:17', '2021-04-07 16:26:17'),
(10, 10, '1617813036.jpeg', '2021-04-07 16:30:36', '2021-04-07 16:30:36'),
(11, 11, '1617813449.jpg', '2021-04-07 16:37:29', '2021-04-07 16:37:29'),
(12, 12, '1617813951.jpg', '2021-04-07 16:45:51', '2021-04-07 16:45:51'),
(13, 13, '1617814031.jpg', '2021-04-07 16:47:11', '2021-04-07 16:47:11'),
(14, 14, '1617814131.jpg', '2021-04-07 16:48:51', '2021-04-07 16:48:51'),
(15, 15, '1617814362.jpg', '2021-04-07 16:52:42', '2021-04-07 16:52:42'),
(16, 16, '1617814512.jpg', '2021-04-07 16:55:12', '2021-04-07 16:55:12'),
(17, 17, '1617815111.jpg', '2021-04-07 17:05:12', '2021-04-07 17:05:12'),
(18, 18, '1617815205.jpg', '2021-04-07 17:06:46', '2021-04-07 17:06:46'),
(19, 19, '1617815469.jpg', '2021-04-07 17:11:09', '2021-04-07 17:11:09'),
(20, 20, '1617815576.jpg', '2021-04-07 17:12:56', '2021-04-07 17:12:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '0=Inactive|1=Active|2=Ban',
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `phone_no`, `email`, `password`, `street_address`, `status`, `ip_address`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Rasel', 'Hossain', 'raselhossain', '01821112191', 'raselcse120@gmail.com', '$2y$10$BVB6PFBXPmAs1zrQ0lmZ3OMrFWM6T7IqE0nnKb.d.wn3yNg4GtvzC', 'Dhaka,bd', 1, '127.0.0.1', NULL, 'DTkEuO0R6BWSPdEtiDOdDyVvhw3q4Jye8qF3ck3QPM9Rvobi7b6MP3RA27YL', '2021-03-12 00:09:52', '2021-03-12 00:14:41'),
(2, 'Rasel2', 'Hossain2', 'rasel2hossain2', '018211121911', 'raselcse1201@gmail.com', '$2y$10$HJEZazqX/bbCbactkfJ9TeZVw9V4XSF1JI/7XN1SqWHANea2k2e1y', 'Dhaka', 0, '127.0.0.1', NULL, 'ftHT5gHeNON7ZJJzzwEl1SbyMx4ds2Brit0F6BDULdJt5nbdqJ', '2021-03-12 08:42:27', '2021-03-12 08:42:27'),
(5, 'fasdg', 'asdfgh', 'fasdgasdfgh', '01845643254', 'takecix720@naymeo.com', '$2y$10$N2uQ2HEjW0hT0jRyCpl8i.EdLA4kwz4aBVx8JFShulvKX0/WU46VG', 'Dhaka', 0, '127.0.0.1', NULL, 'yGDHmnk5zyg15ofk7EWyBOPChWRzz1J5gv0yCI6L6DDgqmZjt7', '2021-03-12 08:49:37', '2021-03-12 08:49:37'),
(6, 'kekavis31', 'vis3', 'kekavis31vis3', '0152162', 'kekavis313@990ys.com', '$2y$10$vLJ2FrPw5S3IcvPRvCLYfOT3280NmPHspXv9bHNneesw5z6T/KL1y', 'gasd', 0, '127.0.0.1', NULL, '8HZUnfay39hETCTx3ovnHjJvuNtOdpKUl1b7CFZv62qg2vDZDh', '2021-03-12 09:00:37', '2021-03-12 09:00:37'),
(7, 'kotel13482@990ys.comq', 'kotel13482@990ys.com', 'kotel13482-at-990yscomqkotel13482-at-990yscom', '23425342', 'kotel13482@990ys.com', '$2y$10$R5XaXmrtgmN05/Eesb5YLe6PbdW.nwsv58GqWkPpesbuHbEibVbb2', '326we', 1, '127.0.0.1', NULL, NULL, '2021-03-12 09:10:08', '2021-03-12 09:10:42'),
(8, 'fitak99748@gameqo.com', 'fitak99748@gameqo.com', 'fitak99748-at-gameqocomfitak99748-at-gameqocom', '54673673', 'fitak99748@gameqo.com', '$2y$10$IUqUv5ejiVxroM5eUfwYV.40V4zbxxYcmS2ANBlvGfDE41cHsNKBe', 'Dhaka', 0, '127.0.0.1', NULL, 'w0FdDRtZedT4jbjAFkVsmv3mIBugbhUz7JEVVCXaO4Fv0hwlLy', '2021-03-14 11:45:54', '2021-03-14 11:45:54'),
(9, 'Rasel2', 'asdfgh', 'rasel2asdfgh', '14236754325', 'tejeb82677@naymeo.com', '$2y$10$sPfRAancd/K4yWTPVMOZh.BIum.rvpQFNP3gHAyWxoQIxpzJoVH26', 'Dhaka', 0, '127.0.0.1', NULL, 'Tsl3RS5M3XaKj9S8FX1SXMZqz6ziDLez29BGgvM7wJXUyJGWxo', '2021-03-14 11:47:00', '2021-03-14 11:47:00'),
(10, 'talikih534@leonvero.com', 'talikih534@leonvero.com', 'talikih534-at-leonverocomtalikih534-at-leonverocom', '5434434534', 'talikih534@leonvero.com', '$2y$10$h96fO6Z6G3dHxA7Apgvpoelr8g22VceAbYyMtGRfjaQgGPdrlLmgu', 'talikih534@leonvero.com', 0, '127.0.0.1', NULL, 'WPVi4fnsB3OwP3XXzjc9CzZw7BEgZ9bTIcyxcmXd2jxrBojF6f', '2021-03-17 00:25:33', '2021-03-17 00:25:33'),
(12, 'xiviwim881@leonvero.com', 'xiviwim881@leonvero.com', 'xiviwim881-at-leonverocomxiviwim881-at-leonverocom', '243789', 'xiviwim881@leonvero.com', '$2y$10$pid5fWTSfZ256.c27WuIDebWJbrC.yhSrePOfXV/R5f/iI1HbVfVe', 'xiviwim881@leonvero.com', 1, '127.0.0.1', NULL, 'ZeZ1I5JBGNVFCR1TSCPWuOg6m3CMjJlnv9Yx3v00a3CrzOJy1iU4fzSwGuG3', '2021-03-17 00:36:10', '2021-03-17 00:36:48'),
(13, 'viteh98482@naymio.com', 'viteh98482@naymio.com', 'viteh98482-at-naymiocomviteh98482-at-naymiocom', '01821767456', 'viteh98482@naymio.com', '$2y$10$foPWznHkUWgD.BVkjEvfAuAtdV8hIWLFtde2h6mkoqpukGJ10ETha', 'Dhaka', 1, '127.0.0.1', NULL, 'mIS5rDacLyFJK8E23abRhykCl298zmNxC4MeHKmoXWLuAOwpdg0SXJ6PAs5M', '2021-03-17 00:48:23', '2021-03-17 01:28:54'),
(14, 'sisomok659@heroulo.com', 'asdfgh', 'sisomok659-at-heroulocomasdfgh', '432545', 'sisomok659@heroulo.com', '$2y$10$fGPneThLMQ7t9wVOH6esVukpP4Q9CVgA7It6a6NRdHYyGSd9c1uBW', 'Dhaka,bd', 1, '127.0.0.1', NULL, 'NUZheKyMm0AXCJ1duU4mBKamrf96MzHmtb2Xitz7aH9ksxCoEpRmQeXYR94g', '2021-03-17 04:04:02', '2021-03-17 04:04:22'),
(15, 'wigete9668@ichkoch.com', 'wigete9668@ichkoch.com', 'wigete9668-at-ichkochcomwigete9668-at-ichkochcom', '54634563453', 'wigete9668@ichkoch.com', '$2y$10$Hf8eyCyNA7tGVlR0flSt.urVupbJ/uS1RCeQ0a1RPcPEmRyjnKDHK', 'wigete9668@ichkoch.com', 1, '127.0.0.1', NULL, 'kOasc3bZppm9360z9O0xYAqXU3aawR1UL4UpO58aHX5Ag0gxLAWYmQYhVRkI', '2021-03-17 07:44:01', '2021-03-17 08:21:01'),
(17, 'honon86693@leonvero.com', 'honon86693@leonvero.com', 'honon86693-at-leonverocomhonon86693-at-leonverocom', '342', 'honon86693@leonvero.com', '$2y$10$imB5KwXvGHf5AqIWcRs.NOAaqJiCehm0nwfwWDf17KGF7tMNuNjn.', '24fds', 1, '::1', NULL, 'bLGBW47JqhxqbcVmXqO5dFUtfTsVecSBgToB4TWC5iurpYuewpgxeOM02rEb', '2021-03-17 08:22:19', '2021-03-17 08:55:44'),
(18, 'jikoyo7231@naymio.com', 'jikoyo7231@naymio.comjikoyo7231@naymio.com', 'jikoyo7231-at-naymiocomjikoyo7231-at-naymiocomjikoyo7231-at-naymiocom', '546345', 'jikoyo7231@naymio.com', '$2y$10$lM9qIHF2NTjrVKzr2F45C.0qTf2QNWmeeP9LYJr.inuGxzh00Nci2', 'wigete9', 1, '::1', NULL, '5ZBBw2SJ4cqHSbO23A7M3N4TS2w3kVtr5lm3TZugfIvKKGdLDQTendqjkSPA', '2021-03-17 08:56:45', '2021-03-17 09:04:57'),
(20, 'jikoyo7231@naymio.com', 'jikoyo7231@naymio.com', 'jikoyo7231-at-naymiocomjikoyo7231-at-naymiocom', 'jikoyo7231@naymio.com', 'jikoyo731@naymio.com', '$2y$10$DYIeG7YH4syfTpKwu.9JS.suYr9P374.4G.AcIlvapq4DuR8T76t2', 'jikoyo7231@naymio.com', 0, '::1', NULL, 'NjjVwEr7oHYFgNJAKml7BXlZZIpMB9gpwteh07j3BsNV69HcWi', '2021-03-17 09:15:05', '2021-03-17 09:15:05'),
(21, 'a', 'b', 'ab', '41121', 'ad@gmail.com', '$2y$10$LoAxDqGye7RUTgLMdeHzGuTF/y7ddManNJj2dmH.U1PdkyNtCGJVO', 'sdfsdf', 0, '::1', NULL, 'FuueL02NcK2Kd6081PHZWh1LpT9XrXELdt80z4hCKnm2WNo4Mq', '2021-03-20 09:53:11', '2021-03-20 09:53:11'),
(25, 'ad', 'bs', 'adbs', '4112125', 'adfd@gmail.com', '$2y$10$aYVTU1v7XDRwioJD.GPlX.hZh//o64pl3wz6auJBQ/jaPEydNRyuS', 'sdfsdfdff', 0, '::1', NULL, 'cXbyjxnxeG9OOYJDGaOctAjKpNSupQ7t9bIGAOMkXzW81gEXW4', '2021-03-20 09:55:02', '2021-03-20 09:55:02'),
(26, 'aff', 'asdf', 'affasdf', '3652312', 'adasd@gmail.com', '$2y$10$yvk17Dac.N2Pehnd6nS9h.BF5xUeYksMh.d6ipVzwqKHtUNl.FUZe', 'asdf', 0, '::1', NULL, 'TUNFC5wCEiedIdMUpyznC15Q8QL6jYHCbeCqSJvFmNEQCzg8VJ', '2021-03-20 09:58:13', '2021-03-20 09:58:13'),
(27, 'a dsd', 'asdf', 'a-dsdasdf', '5121', 'asdfasdf@gmail.com', '$2y$10$68DLw23eKE6gC.FQzDq/DO1cnkGIGi8dTuSn.34NdijClX3E5OQ06', 'asdfasdf', 0, '::1', NULL, '0Q4kDpkBRvZkieSp5snbrtzFFVEAls0Moh5J4lhOJK2f2bs10h', '2021-03-20 10:01:20', '2021-03-20 10:01:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_foreign` (`user_id`),
  ADD KEY `carts_product_id_foreign` (`product_id`),
  ADD KEY `carts_order_id_foreign` (`order_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_payment_id_foreign` (`payment_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payments_short_name_unique` (`short_name`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_phone_no_unique` (`phone_no`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

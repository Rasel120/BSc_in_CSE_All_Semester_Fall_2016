<footer class="footer-bottom">
  <p class="text-center">&copy; 2021 All rights reserved | Online Ecommerce Shop</p>
</footer>

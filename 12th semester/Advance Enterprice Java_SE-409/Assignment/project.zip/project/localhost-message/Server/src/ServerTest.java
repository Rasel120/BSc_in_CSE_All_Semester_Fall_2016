public class ServerTest {
	
        
	public static void main(String[] args) {
		    
		MainServer myServer=new MainServer();
                myServer.startRunning();
	}
}

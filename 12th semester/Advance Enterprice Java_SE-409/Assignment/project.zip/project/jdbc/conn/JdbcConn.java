/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc.conn;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Pias_CSE!
 */
public class JdbcConn {

   

    
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        
        String url = "jdbc:mysql://127.0.0.1/school";
        String username = "root";
        String password = "";
        String query = " SELECT * FROM students where id=7";
        
         Class.forName("com.mysql.jdbc.Driver");
         Connection connection = (Connection) DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        ResultSet result;
        result = statement.executeQuery(query);
        result.next();
        String name = result.getString("name");
        String roll = result.getString("roll");
        String dob = result.getString("dob");
        System.out.println("connection success. Name : " +name);
        System.out.println("Roll : " +roll);
        System.out.println("Date of birth : " +dob);
        connection.close();
        statement.close();
    
    }
    
}


import java.sql.*;

public class dbAccess
{
    public static void main(String[] args)
    {
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            String database = 
              "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=student.accdb;";
            Connection conn = DriverManager.getConnection(database, "", "");
            Statement s = conn.createStatement();
            
                        
            // Fetch table
            String selTable = "SELECT * FROM student";
            s.execute(selTable);
            ResultSet rs = s.getResultSet();
            while((rs!=null) && (rs.next()))
            {
                System.out.println(rs.getString(1) + " : " + rs.getString(2));
            }
            
            
            
            // close and cleanup
            s.close();
            conn.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
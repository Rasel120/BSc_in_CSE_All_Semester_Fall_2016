// File: IPFinder.java
// Get the IP address of a host

import java.net.*;
import java.io.*;
import javax.swing.*;


public class IPFinder
{
	public static void main(String[] args) throws IOException
	{
		String host;
		host = JOptionPane.showInputDialog("Please input the server's name");
		try
		{
			InetAddress address = InetAddress.getByName(host);
		    JOptionPane.showMessageDialog(null,"IP address: " + address.toString());

		}
     		catch (UnknownHostException e)
     		{JOptionPane.showMessageDialog(null,"Could not find " + host);
		}
	}
}


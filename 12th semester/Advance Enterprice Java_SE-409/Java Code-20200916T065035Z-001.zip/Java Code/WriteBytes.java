import java.io.*;

class WriteBytes
{
	public static void main(String args[])
	{
		byte cities[]={'D','H','A','K','A','K','H','U','L','N','A'};
		FileOutputStream outfile = null;
		try{
			outfile= new FileOutputStream("city.txt");
			outfile.write(cities);
			outfile.close();
		}
		catch(IOException ioe){}
	}
}
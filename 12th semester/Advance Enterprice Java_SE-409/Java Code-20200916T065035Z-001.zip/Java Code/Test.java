class Test
{
public static void main(String args[])
{
	System.out.println("Welcome Spring 2020");
	System.out.println("CSE Batch 42");
}
}
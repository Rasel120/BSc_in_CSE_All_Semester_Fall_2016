

     Step 1: Install the program
     Step 2: Run the application
     Step 3: Use keygen or "serial key.txt" to register the application.
          